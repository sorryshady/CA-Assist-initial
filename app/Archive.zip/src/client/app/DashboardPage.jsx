import React from 'react'

export const DashboardPage = () => {
  return (
    <div>DashboardPage</div>
  )
}
