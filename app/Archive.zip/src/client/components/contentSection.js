export const navigation = [
  { name: 'AI Scheduler (Demo App)', href: '/demo-app' },
  { name: 'File Upload (AWS S3)', href: '/file-upload' },
  { name: 'Pricing', href: '/pricing' },
  { name: 'Documentation', href: 'https://wasp-lang.dev' },
  { name: 'Blog', href: 'https://wasp-lang.dev' },
]
