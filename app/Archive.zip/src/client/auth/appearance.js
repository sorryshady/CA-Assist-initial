export const authAppearance = {
  colors: {
    brand: '#0f172a',
    brandAccent: '#272e3f',
    submitButtonText: '#f8fafc',
  },
}
